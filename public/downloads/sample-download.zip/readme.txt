NovaCart sample download file.
Use this file to test automatic fileDownload tracking.
